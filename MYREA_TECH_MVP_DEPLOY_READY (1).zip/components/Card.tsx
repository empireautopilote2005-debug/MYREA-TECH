export default function Card({children}:{children:React.ReactNode}){
 return <div className="rounded-xl border p-5 shadow">{children}</div>
}
