# MYREA TECH SaaS V1

Plateforme SaaS collaborative MYREA TECH.

## Stack
- Next.js 15
- TypeScript
- Tailwind CSS
- Supabase Auth
- PostgreSQL
- Cloudflare Pages

## Déploiement Cloudflare

Build command:
npm run build

Variables:
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY

## Modules
- Authentification
- Communautés
- Invitations membres
- Idées CRUD
- Projets Kanban
- Statistiques
- Sécurité RLS
