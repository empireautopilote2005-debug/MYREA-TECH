export default function Home(){
 return (
  <main>
   <h1>MYRÉA TECH SaaS</h1>
   <p>Transformer les idées collectives en actifs.</p>
  </main>
 )
}
