import StatCard from '@/components/dashboard/StatCard';

export default function Dashboard(){
 return <main>
 <h1>Dashboard MYRÉA TECH</h1>
 <StatCard title="Communautés" value="0"/>
 <StatCard title="Idées" value="0"/>
 <StatCard title="Projets" value="0"/>
 <StatCard title="Actifs" value="0"/>
 </main>
}
