# Architecture MYREA TECH SaaS V1

Frontend:
Next.js + TypeScript

Backend:
Supabase Auth + PostgreSQL

Sécurité:
Row Level Security

Déploiement:
Cloudflare Pages
