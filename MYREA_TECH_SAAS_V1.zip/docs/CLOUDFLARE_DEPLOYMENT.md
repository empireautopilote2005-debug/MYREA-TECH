# Déploiement Cloudflare Pages

1. Envoyer le projet sur GitHub.
2. Connecter GitHub à Cloudflare Pages.
3. Framework: Next.js.
4. Ajouter les variables Supabase.
5. Déployer.

Après déploiement:
- vérifier Auth Supabase
- vérifier RLS
- tester création communauté
