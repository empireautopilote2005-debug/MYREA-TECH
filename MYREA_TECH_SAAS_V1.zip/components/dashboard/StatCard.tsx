export default function StatCard({title,value}:{title:string,value:string}){
 return <div className="rounded-xl border p-5">
 <h3>{title}</h3>
 <strong>{value}</strong>
 </div>
}
