create table profiles(
 id uuid primary key references auth.users(id),
 full_name text,
 avatar_url text,
 created_at timestamp default now()
);

create table communities(
 id uuid primary key default gen_random_uuid(),
 name text not null,
 description text,
 owner_id uuid references auth.users(id),
 created_at timestamp default now()
);

create table community_members(
 id uuid primary key default gen_random_uuid(),
 community_id uuid references communities(id) on delete cascade,
 user_id uuid references auth.users(id) on delete cascade,
 role text default 'member'
);

create table community_invitations(
 id uuid primary key default gen_random_uuid(),
 community_id uuid references communities(id),
 email text,
 token text unique,
 status text default 'pending'
);

create table ideas(
 id uuid primary key default gen_random_uuid(),
 community_id uuid references communities(id),
 title text,
 description text,
 status text default 'new',
 created_at timestamp default now()
);

create table projects(
 id uuid primary key default gen_random_uuid(),
 community_id uuid references communities(id),
 name text,
 status text default 'todo'
);

create table tasks(
 id uuid primary key default gen_random_uuid(),
 project_id uuid references projects(id),
 title text,
 status text default 'todo'
);

alter table communities enable row level security;
alter table ideas enable row level security;
alter table projects enable row level security;

create policy "community members access"
on communities for select
using (
 auth.uid() in (
  select user_id from community_members
  where community_id=communities.id
 )
);
